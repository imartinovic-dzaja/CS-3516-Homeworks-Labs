Extract imartinovic_project3.zip to any location you wish
cd to the location where source code was extracted and type "make" to compile the code
Type "./project3" to run the code

